package com.example.sosalert;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_PERMISSIONS = 100;
    private FusedLocationProviderClient fusedLocationClient;
    private TextToSpeech textToSpeech;
    private Vibrator vibrator;

    // Predefined list of emergency contact numbers (replace with actual numbers)
    private List<String> emergencyNumbers = new ArrayList<>(Arrays.asList(
            "+916300750791", // Example: +1 (234) 567-8900
            "+918722611600"// Example: +1 (987) 654-3210
    ));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        textToSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    textToSpeech.setLanguage(Locale.US);
                }
            }
        });

        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        Button sosButton = findViewById(R.id.sos_button);
        sosButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPermissionsAndSendSOS();
            }
        });
    }

    private void requestPermissionsAndSendSOS() {
        // Check and request permissions for Android 13+
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.SEND_SMS},
                    REQUEST_PERMISSIONS);
        } else {
            sendSOS();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                    grantResults[1] == PackageManager.PERMISSION_GRANTED &&
                    grantResults[2] == PackageManager.PERMISSION_GRANTED) {
                sendSOS();
            } else {
                Toast.makeText(this, "Permissions denied. Cannot send SOS.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendSOS() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    if (location != null) {
                        double latitude = location.getLatitude();
                        double longitude = location.getLongitude();
                        String locationMessage = "Location: https://maps.google.com/?q=" + latitude + "," + longitude;

                        String message = "I am in emergency. " + locationMessage;

                        // Send SMS using SmsManager (will use default SMS app, e.g., Google Messages)
                        SmsManager smsManager = SmsManager.getDefault();
                        for (String number : emergencyNumbers) {
                            try {
                                // Split the message if it’s too long (SMS limit is 160 characters per part)
                                ArrayList<String> messageParts = smsManager.divideMessage(message);
                                smsManager.sendMultipartTextMessage(number, null, messageParts, null, null);
                                Toast.makeText(MainActivity.this, "SOS sent to " + number, Toast.LENGTH_SHORT).show();
                            } catch (Exception e) {
                                Toast.makeText(MainActivity.this, "Failed to send SMS to " + number, Toast.LENGTH_SHORT).show();
                                e.printStackTrace();
                            }
                        }

                        // Provide feedback
                        if (textToSpeech != null) {
                            textToSpeech.speak("SOS alert sent", TextToSpeech.QUEUE_FLUSH, null, null);
                        }
                        if (vibrator != null && vibrator.hasVibrator()) {
                            vibrator.vibrate(500); // Vibrate for 500ms
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "Unable to get location. Sending SOS without location.", Toast.LENGTH_SHORT).show();
                        sendSOSWithoutLocation();
                    }
                }
            });
        }
    }

    private void sendSOSWithoutLocation() {
        String message = "I am in emergency. Unable to retrieve location.";
        SmsManager smsManager = SmsManager.getDefault();
        for (String number : emergencyNumbers) {
            try {
                ArrayList<String> messageParts = smsManager.divideMessage(message);
                smsManager.sendMultipartTextMessage(number, null, messageParts, null, null);
                Toast.makeText(this, "SOS sent to " + number, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send SMS to " + number, Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        }

        // Provide feedback
        if (textToSpeech != null) {
            textToSpeech.speak("SOS alert sent without location", TextToSpeech.QUEUE_FLUSH, null, null);
        }
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(500); // Vibrate for 500ms
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (textToSpeech != null) {
            textToSpeech.shutdown();
        }
    }
}