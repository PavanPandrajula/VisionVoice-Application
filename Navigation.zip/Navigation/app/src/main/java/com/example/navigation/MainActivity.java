package com.example.navigation;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "MyAppPrefs";
    private static final String FIRST_LAUNCH_KEY = "firstLaunch";
    private TextToSpeech tts;
    private ActivityResultLauncher<Intent> speechRecognitionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the button with a lambda expression
        Button navigateButton = findViewById(R.id.navigate_button);
        navigateButton.setOnClickListener(v -> startNavigation());

        // Initialize Text-to-Speech with a lambda expression
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.US);
                // Announce instructions on app open
                tts.speak("Press the button in the middle to start navigation", TextToSpeech.QUEUE_FLUSH, null, null);
            }
        });

        // Initialize speech recognition launcher to replace startActivityForResult
        speechRecognitionLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        List<String> results = result.getData().getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                        if (results != null && !results.isEmpty()) {
                            String spokenText = results.get(0); // Null check added to avoid NullPointerException
                            if (tts != null) {
                                tts.speak("Navigating to " + spokenText, TextToSpeech.QUEUE_FLUSH, null, null);
                            }
                            openGoogleMapsNavigation(spokenText);
                        } else {
                            if (tts != null) {
                                tts.speak("No destination recognized. Please try again.", TextToSpeech.QUEUE_FLUSH, null, null);
                            }
                        }
                    } else {
                        if (tts != null) {
                            tts.speak("Sorry, I didn’t understand. Please try again.", TextToSpeech.QUEUE_FLUSH, null, null);
                        }
                    }
                }
        );

        // Show instructions on first launch
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean isFirstLaunch = prefs.getBoolean(FIRST_LAUNCH_KEY, true);
        if (isFirstLaunch) {
            showInstructionDialog();
            prefs.edit().putBoolean(FIRST_LAUNCH_KEY, false).apply();
        }
    }

    // Extracted method to create the dialog for better code organization
    private AlertDialog createInstructionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Important");
        builder.setMessage("For the best experience, enable Detailed Voice Guidance in Google Maps settings.");
        builder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss()); // Lambda expression used here
        return builder.create();
    }

    // Method to show the instruction dialog
    private void showInstructionDialog() {
        AlertDialog dialog = createInstructionDialog();
        dialog.show();
        if (tts != null) {
            tts.speak("For the best experience, enable Detailed Voice Guidance in Google Maps settings.", TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }

    // Start navigation with speech input
    private void startNavigation() {
        if (isSpeechRecognitionAvailable()) {
            // Provide audible feedback before launching speech recognition
            if (tts != null) {
                tts.speak("say", TextToSpeech.QUEUE_FLUSH, null, null);
            }
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say your destination");
            speechRecognitionLauncher.launch(intent);
        } else {
            if (tts != null) {
                tts.speak("Speech recognition is not available on this device.", TextToSpeech.QUEUE_FLUSH, null, null);
            }
        }
    }

    // Check if speech recognition is available
    private boolean isSpeechRecognitionAvailable() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        return intent.resolveActivity(getPackageManager()) != null;
    }

    // Open Google Maps with the specified destination
    private void openGoogleMapsNavigation(String destination) {
        String uri = "google.navigation:q=" + Uri.encode(destination);
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        intent.setPackage("com.google.android.apps.maps");
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            if (tts != null) {
                tts.speak("Google Maps is not installed. Please install it.", TextToSpeech.QUEUE_FLUSH, null, null);
            }
            Intent playStoreIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.apps.maps"));
            startActivity(playStoreIntent);
        }
    }

    // Clean up TTS resources
    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
