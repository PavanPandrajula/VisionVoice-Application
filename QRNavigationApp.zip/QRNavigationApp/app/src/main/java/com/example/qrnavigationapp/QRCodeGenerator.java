package com.example.qrnavigationapp;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;

public class QRCodeGenerator extends AppCompatActivity {

    private ImageView qrCodeImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr_generator);

        qrCodeImageView = findViewById(R.id.qrCodeImageView);
        Button generateQRButton = findViewById(R.id.generateQRButton);

        generateQRButton.setOnClickListener(v -> generateAndSaveQRCodes());
    }

    private void generateAndSaveQRCodes() {
        // Map each room code to itself so that the generated QR text exactly matches your database IDs.
        HashMap<String, String> roomCodes = new HashMap<>();
        roomCodes.put("Room1_Bedroom", "Room1_Bedroom");
        roomCodes.put("Room2_Bedroom2", "Room2_Bedroom2");
        roomCodes.put("Room3_LivingRoom", "Room3_LivingRoom");

        // Generate and save a QR code for each room
        for (String key : roomCodes.keySet()) {
            String qrContent = roomCodes.get(key);
            saveQRCodeToFile(qrContent, key + ".png");
        }
        Toast.makeText(this, "QR Codes Saved!", Toast.LENGTH_LONG).show();
    }

    private void saveQRCodeToFile(String data, String fileName) {
        try {
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            // Generate a QR code bitmap with specified width and height (400x400)
            Bitmap bitmap = barcodeEncoder.encodeBitmap(data, com.google.zxing.BarcodeFormat.QR_CODE, 400, 400);

            // Save the generated QR code as a PNG image in the app's external Pictures directory
            File qrCodeFile = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), fileName);
            FileOutputStream outputStream = new FileOutputStream(qrCodeFile);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
            outputStream.flush();
            outputStream.close();

            // Optionally, display the last generated QR code in the ImageView
            qrCodeImageView.setImageBitmap(bitmap);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error saving QR Code!", Toast.LENGTH_SHORT).show();
        }
    }
}
