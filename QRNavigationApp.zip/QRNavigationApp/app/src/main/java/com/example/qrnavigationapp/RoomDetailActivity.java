package com.example.qrnavigationapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import java.util.Locale;

public class RoomDetailActivity extends AppCompatActivity {

    private static final String TAG = "RoomDetailActivity";
    private TextToSpeech tts;
    private TextView roomIdTextView, roomDetailsTextView;
    private CardView roomIdCard, roomDetailsCard;
    private DatabaseHelper dbHelper;
    private static final String UTTERANCE_ID = "RoomDetailsUtterance";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_detail);

        // Initialize views
        roomIdTextView = findViewById(R.id.roomIdTextView);
        roomDetailsTextView = findViewById(R.id.roomDetailsTextView);
        roomIdCard = findViewById(R.id.roomIdCard);
        roomDetailsCard = findViewById(R.id.roomDetailsCard);

        dbHelper = new DatabaseHelper(this);

        // Retrieve the room name from the Intent extra and trim any extra spaces
        final String roomNameFromIntent = getIntent().getStringExtra("ROOM_NAME");
        final String roomName = (roomNameFromIntent != null) ? roomNameFromIntent.trim() : "";
        Log.d(TAG, "Scanned Room Name: '" + roomName + "'");

        // Get room details from the database using the cleaned room name
        String details = getRoomDetails(roomName);
        Log.d(TAG, "Fetched Room Details: " + details);

        // Update UI with room name and details
        roomIdTextView.setText(roomName);
        roomDetailsTextView.setText(details);

        // Apply fade-in animation (ensure res/anim/fade_in.xml exists)
        Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        roomIdCard.startAnimation(fadeIn);
        roomDetailsCard.startAnimation(fadeIn);

        // Initialize TextToSpeech
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.US);
                String speechText = "You are in " + roomName + ". " + details + ". Going back to home screen.";
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override
                    public void onStart(String utteranceId) {
                        Log.d(TAG, "TTS Started");
                    }
                    @Override
                    public void onDone(String utteranceId) {
                        Log.d(TAG, "TTS Completed");
                        runOnUiThread(() -> {
                            Intent intent = new Intent(RoomDetailActivity.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                        });
                    }
                    @Override
                    public void onError(String utteranceId) {
                        Log.e(TAG, "TTS Error");
                    }
                });
                tts.speak(speechText, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID);
            }
        });
    }

    private String getRoomDetails(String roomName) {
        // Use the trimmed roomName as the key
        Log.d(TAG, "Querying database for room: '" + roomName + "'");
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT details FROM rooms WHERE name=?", new String[]{roomName});
        String details;
        if (cursor.moveToFirst()) {
            details = cursor.getString(0);
            Log.d(TAG, "Database query successful for room: '" + roomName + "'");
        } else {
            details = "No details available.";
            Log.d(TAG, "No matching row found in database for room: '" + roomName + "'");
        }
        cursor.close();
        return details;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
    }
}
