package com.example.qrnavigationapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    // Increase the database version if you change the schema (to force onUpgrade)
    private static final String DATABASE_NAME = "room_navigation.db";
    private static final int DATABASE_VERSION = 2;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the table
        db.execSQL("CREATE TABLE rooms (id INTEGER PRIMARY KEY, name TEXT, details TEXT)");

        // Insert rows – ensure these strings exactly match the QR code values
        db.execSQL("INSERT INTO rooms (name, details) VALUES (" +
                "'Room1_Bedroom', " +
                "'1. Bed on right side once you enter\n" +
                "2. Study table and chargers on left\n" +
                "3. Switch boards adjacent to the wall inside\n" +
                "4. Windows available when you walk straight and left\n" +
                "5. Chair near the table\n" +
                "6. Stools when you move 10cm forward\n" +
                "7. Take right and walk 15cm, TV is available\n" +
                "8. Shelfs available behind the bed')");

        db.execSQL("INSERT INTO rooms (name, details) VALUES (" +
                "'Room2_Bedroom2', " +
                "'1. Washroom on the left when you walk 10cm\n" +
                "2. Bed straight ahead of the room\n" +
                "3. Walk left and take right to access the shelfs\n" +
                "4. Switch boards are left adjacent to the door\n" +
                "5. Walk left 5m and take right 3m to reach the table\n" +
                "6. Medicines on the table')");

        db.execSQL("INSERT INTO rooms (name, details) VALUES (" +
                "'Room3_LivingRoom', " +
                "'1. Switch board on the right\n" +
                "2. Beds on left and right\n" +
                "3. Shelfs available when you walk straight 8-10cm\n" +
                "4. A/C remote on the left of the door and all other accessories\n" +
                "5. Washroom is available when you walk straight 5-6m and take right')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // For testing purposes, drop the table and recreate it. In production, consider migration strategies.
        db.execSQL("DROP TABLE IF EXISTS rooms");
        onCreate(db);
    }
}
