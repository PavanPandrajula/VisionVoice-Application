package com.example.qrnavigationapp;

import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextToSpeech tts;
    private Button scanQRButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        scanQRButton = findViewById(R.id.scanQRButton);

        // Initialize TextToSpeech to announce the instruction
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.US);
                tts.speak("Press the button in the middle to scan the QR code", TextToSpeech.QUEUE_FLUSH, null, "INSTRUCTION");
            }
        });

        // Load button click animation from res/anim/button_click.xml
        final Animation buttonAnimation = AnimationUtils.loadAnimation(this, R.anim.button_click);

        scanQRButton.setOnClickListener(v -> {
            v.startAnimation(buttonAnimation);
            // After animation, navigate to QRCodeScannerActivity
            v.postDelayed(() -> {
                Intent intent = new Intent(MainActivity.this, QRCodeScannerActivity.class);
                startActivity(intent);
            }, buttonAnimation.getDuration());
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
    }
}
