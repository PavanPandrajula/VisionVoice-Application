package com.example.barcodescanner;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import com.google.zxing.BarcodeFormat;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;
import com.journeyapps.barcodescanner.DefaultDecoderFactory;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private DecoratedBarcodeView barcodeScannerView;
    private TextToSpeech textToSpeech;
    private boolean processingBarcode = false; // Prevents processing multiple scans at once

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanner);  // Use our custom scanner layout

        barcodeScannerView = findViewById(R.id.barcode_scanner);
        // Set the desired barcode formats (using BarcodeFormat enums)
        barcodeScannerView.getBarcodeView().setDecoderFactory(
                new DefaultDecoderFactory(Arrays.asList(
                        BarcodeFormat.QR_CODE,
                        BarcodeFormat.EAN_13,
                        BarcodeFormat.UPC_A
                ))
        );
        // Start continuous scanning
        barcodeScannerView.decodeContinuous(callback);

        // Initialize Text-to-Speech
        textToSpeech = new TextToSpeech(getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech.setLanguage(Locale.ENGLISH);
                speakOut("Press the button in the bottom center to scan the QR codes.");
            }
        });

        requestCameraPermission();
    }

    private void requestCameraPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 100);
        }
    }

    // Continuous barcode callback
    private final BarcodeCallback callback = new BarcodeCallback() {
        @Override
        public void barcodeResult(BarcodeResult result) {
            // Process only if text is available and we're not already processing a barcode
            if (result.getText() != null && !processingBarcode) {
                processingBarcode = true;
                String barcode = result.getText();
                fetchProductDetails(barcode);
            }
        }
    };

    // Fetch product details from OpenFoodFacts API
    private void fetchProductDetails(String barcode) {
        new Thread(() -> {
            try {
                String apiUrl = "https://world.openfoodfacts.org/api/v2/product/" + barcode + ".json";
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                processProductResponse(response.toString());
            } catch (Exception e) {
                speakOut("Could not connect to product database.");
                // Allow new scans after error
                barcodeScannerView.postDelayed(() -> processingBarcode = false, 2000);
            }
        }).start();
    }

    // Process the API response and announce the product
    private void processProductResponse(String response) {
        try {
            JSONObject jsonResponse = new JSONObject(response);
            if (jsonResponse.has("product")) {
                JSONObject product = jsonResponse.getJSONObject("product");
                String productName = product.has("product_name") ? product.getString("product_name") : "Unknown Product";
                speakOut("Product detected: " + productName);
            } else {
                speakOut("Product not found in database.");
            }
        } catch (JSONException e) {
            speakOut("Error reading product data.");
        } finally {
            // Allow next scan after a short delay
            barcodeScannerView.postDelayed(() -> processingBarcode = false, 2000);
        }
    }

    // Announce a message via TTS and provide haptic feedback
    private void speakOut(String text) {
        textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
        vibratePhone();
    }

    private void vibratePhone() {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        barcodeScannerView.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        barcodeScannerView.pause();
    }

    @Override
    protected void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }
}
