package com.example.sendmessage;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextToSpeech tts;
    private EditText contactNameField, messageField;
    private Button speakButton;

    private int currentStep = 0; // 0 = waiting, 1 = getting contact, 2 = getting message
    private String contactName = "";
    private String messageToSend = "";

    private ActivityResultLauncher<Intent> speechLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contactNameField = findViewById(R.id.contactName);
        messageField = findViewById(R.id.messageContent);
        speakButton = findViewById(R.id.speakButton);

        // Request SMS permission
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
        }

        // Initialize TTS
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.US);
                tts.setPitch(0.9f); // Deeper/male-like voice
                tts.setSpeechRate(1.2f);
                speak("Press the button in the middle to start.", () -> {});
            } else {
                Toast.makeText(this, "TTS Initialization Failed!", Toast.LENGTH_SHORT).show();
            }
        });

        // Speech recognition launcher
        speechLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        List<String> results = result.getData().getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                        if (results != null && !results.isEmpty()) {
                            handleVoiceInput(results.get(0));
                        }
                    } else {
                        speak("I didn't catch that. Please try again.", () -> {});
                    }
                }
        );

        speakButton.setOnClickListener(v -> startFlow());
    }

    private void startFlow() {
        currentStep = 1;
        speak("Tell me the contact name.", this::startSpeechInput);
    }

    private void startSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now...");
        speechLauncher.launch(intent);
    }

    private void handleVoiceInput(String result) {
        if (currentStep == 1) {
            contactName = result;
            contactNameField.setText(contactName);
            currentStep = 2;
            speak("Please tell me the message for sending to " + contactName, this::startSpeechInput);
        } else if (currentStep == 2) {
            messageToSend = result;
            messageField.setText(messageToSend);
            sendMessage();
        }
    }

    private void sendMessage() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(contactName, null, messageToSend, null, null);
            speak("I have sent the message.", () -> {});
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
            speak("Sorry, the message could not be sent.", () -> {});
        }
        currentStep = 0;
    }

    private void speak(String text, Runnable onComplete) {
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) { }

            @Override
            public void onDone(String utteranceId) {
                runOnUiThread(onComplete);
            }

            @Override
            public void onError(String utteranceId) {
                runOnUiThread(onComplete);
            }
        });

        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utteranceId");
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    // Handle SMS permission result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1 &&
                (grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED)) {
            Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
        }
    }
}