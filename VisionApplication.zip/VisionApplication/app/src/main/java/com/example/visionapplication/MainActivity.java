package com.example.visionapplication;

import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private final String[][] pairedApps = {
            {"com.example.sendmessage", "com.example.sendmessage.MainActivity"},
            {"com.example.sosalert", "com.example.sosalert.MainActivity"},
            {"com.example.navigation", "com.example.navigation.MainActivity"},
            {"com.example.qrnavigationapp", "com.example.qrnavigationapp.MainActivity"},
            {"com.example.barcodescanner", "com.example.barcodescanner.MainActivity"}
    };

    private TextToSpeech textToSpeech;
    private final HashMap<Integer, Long> lastClickMap = new HashMap<>();
    private static final int DOUBLE_CLICK_TIME_DELTA = 1000; // milliseconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech.setLanguage(Locale.US);
            }
        });

        setButtonLogic(findViewById(R.id.button1), 0);
        setButtonLogic(findViewById(R.id.button2), 1);
        setButtonLogic(findViewById(R.id.button3), 2);
        setButtonLogic(findViewById(R.id.button4), 3);
        setButtonLogic(findViewById(R.id.button5), 4);
    }

    private void setButtonLogic(Button button, int index) {
        button.setOnClickListener(v -> {
            int buttonId = button.getId();
            long currentTime = System.currentTimeMillis();
            Long lastClickTime = lastClickMap.get(buttonId);

            String buttonText = button.getText().toString();

            if (lastClickTime != null && (currentTime - lastClickTime < DOUBLE_CLICK_TIME_DELTA)) {
                // Double-click detected
                launchPairedApp(pairedApps[index][0], pairedApps[index][1], buttonText);
                lastClickMap.remove(buttonId);
            } else {
                // First click
                speak(buttonText);
                lastClickMap.put(buttonId, currentTime);

                // Optional: reset after timeout to prevent false positives
                new Handler().postDelayed(() -> {
                    if (lastClickMap.containsKey(buttonId) &&
                            System.currentTimeMillis() - lastClickMap.get(buttonId) >= DOUBLE_CLICK_TIME_DELTA) {
                        lastClickMap.remove(buttonId);
                    }
                }, DOUBLE_CLICK_TIME_DELTA + 100);
            }
        });
    }

    private void speak(String text) {
        if (textToSpeech != null) {
            textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }

    private void launchPairedApp(String packageName, String className, String appName) {
        try {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName(packageName, className));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, appName + " not found or not accessible", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error launching " + appName, Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }
}
